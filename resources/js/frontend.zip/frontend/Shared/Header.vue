<template>
    <!-- header start -->
    <header>
        <!-- Header -->
    </header>
    <!-- header end -->
</template>

<script>

export default {
    data: () => ({
        is_home: true,
        search: "",
    }),

};
</script>

<style scoped></style>
